package es.ua.eps.drawables

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class Drawables : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }
}